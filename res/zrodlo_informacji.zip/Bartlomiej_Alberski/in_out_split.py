import sys

if __name__ == '__main__':
    f = open(sys.argv[1],"r")
    fin = open(sys.argv[1]+".in","w")
    fout = open(sys.argv[1] + ".out","w")
    for line in f:
        b = line.split("\t")
        fin.write(b[0]+".0" + "\t" + b[1]+".0" + "\t" + b[2]+".0" + "\n")
        a = b[3].split("\n")
        fout.write(a[0]+".0" + "\n")
    fin.flush()
    fout.flush()
    fin.close()
    fout.close()
    f.close()