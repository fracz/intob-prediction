
import random
import sys

if __name__ == '__main__':
    f = open(sys.argv[1],"r")
    random.seed()
    flearning = open("learning","w")
    ftesting = open("testing","w")
    for line in f:
        b = random.randint(1,5)
        if b == 3:
            ftesting.write(line)
        else:
            flearning.write(line)
    ftesting.flush()
    flearning.flush()
    ftesting.close()
    flearning.close()
    f.close()
		