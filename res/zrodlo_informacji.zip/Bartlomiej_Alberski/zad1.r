require(AMORE)
setwd("C:/Users/Bartek/Studia/Semestr VII/msi")
learningin = read.table("learning.in")
out = cbind(learningin[,1],learningin[,2])
learningin = cbind(out,learningin[,3])
learningout = read.table("learning.out")
learningout = learningout[,1]
testingin = read.table("testing.in")
out = cbind(testingin [,1],testingin [,2])
testingin = cbind(out,testingin [,3])
testingout = read.table("testing.out")
testingout = testingout[,1]
 
## We create two artificial data sets. ''P'' is the input data set. ''target'' is the output.
net.start <- newff(n.neurons=c(3,5,3,1),      
             learning.rate.global=1e-2,        
             momentum.global=0.5,              
             error.criterium="LMS",           
             Stao=NA, hidden.layer="tansig",   
             output.layer="purelin",           
             method="ADAPTgdwm") 
 
## We train the network according to P and target.
err = mat.or.vec(48914,1)
for (j in seq(1,120)){
result <- train(net.start, learningin, learningout, error.criterium="LMS", report=TRUE, show.step=j, n.shows=5 )
err[j] <- 0
## Several graphs, mainly to remark that 
## now the trained network is is an element of the resulting list.lea
y <- sim(result$net, testingin)

for (i in seq(1,48914))
	err[j] = err[j] + (testingout[i] - y[i])* (testingout[i] - y[i])
err[j] = err[j]/48914
err[j] = sqrt(err[j])

}