input <- read.csv('./data.in', header=FALSE, sep = ".", dec=",", fill = TRUE)


P <- NULL
for(i in seq(1:200)){
 a <- i+4
 P <- rbind(P, input[i:a,])
}

target <- input[6:205,]
target <- matrix(target, ncol=1)

net.start <- newff(n.neurons=c(5,8,4,2,1), learning.rate.global=1e-2,
momentum.global=0.5, error.criterium="LMS", Stao=NA,
hidden.layer="tansig", output.layer="purelin", method="ADAPTgdwm")

result <- train(net.start, P, target, error.criterium="LMS",
report=TRUE, show.step=5000, n.shows=5)


error <- matrix(0, nrow=200, ncol=1)
predicted <- matrix(0, nrow=200, ncol=1)
for( i in c(1:200)){
        simuls <- matrix(P[i,], ncol=5, nrow=1)
        predicted[i] <- sim(result$net, simuls)
        error[i] <- abs(predicted[i] - input[i+5,])
}


plot(1:200, input[1:200,], col="red", type="l")
lines(1:200, predicted, col="green")